import numpy as np
from  fyers_apiv3 import fyersModel
from time import sleep
import time
import requests as req
import datetime as dt
from urllib.parse import parse_qs, urlparse
import joblib
import pyotp


def login(secret_key, client_id, redirect_uri, fy_id, pin, totp):
    BASE_URL = "https://api-t2.fyers.in/vagator/v2"
    BASE_URL_2 = "https://api-t1.fyers.in/api/v3"
    URL_SEND_LOGIN_OTP = BASE_URL + "/send_login_otp"
    URL_VERIFY_TOTP = BASE_URL + "/verify_otp"
    URL_VERIFY_PIN = BASE_URL + "/verify_pin"
    URL_TOKEN = BASE_URL_2 + "/token"
    URL_VALIDATE_AUTH_CODE = BASE_URL_2 + "/validate-authcode"
    res = req.post(url=URL_SEND_LOGIN_OTP, json={"fy_id": fy_id, "app_id": "2"}).json()
    if dt.datetime.now().second % 30 > 27: time.sleep(5)
    vari_topt = req.post(url=URL_VERIFY_TOTP,
                         json={"request_key": res['request_key'], "otp": pyotp.TOTP(totp).now()}).json()

    ses = req.Session()

    time.sleep(.5)
    vari_pin_payload = {"request_key": vari_topt["request_key"], "identity_type": "pin", "identifier": f"{int(pin)}"}

    vari_pin = req.post(url=URL_VERIFY_PIN, json=vari_pin_payload).json()

    ses.headers.update({"authorization": f"Bearer {vari_pin['data']['access_token']}"})
    token_payload3 = {
        "fyers_id": fy_id,
        "app_id": client_id[:-4],
        "redirect_uri": redirect_uri,
        "appType": "100", "code_challenge": "",
        "state": "None", "scope": "", "nonce": "",
        "response_type": "code", "create_cookie": True
    }

    token_ = ses.post(url=URL_TOKEN, json=token_payload3).json()

    url = token_['Url']
    parsed = urlparse(url)
    auth_code = parse_qs(parsed.query)['auth_code'][0]

    session = fyersModel.SessionModel(
        client_id=client_id,
        secret_key=secret_key,
        redirect_uri=redirect_uri,
        response_type='code',
        grant_type='authorization_code'
    )
    session.set_token(auth_code)
    response = session.generate_token()
    access_token = response['access_token']
    fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")
    return access_token, fyers
path = "F:\\Portfolio Projects\\Python\\Finance Projects\\nikhi"
client_data = joblib.load(path)
credential = {
    'secret_key': client_data.get('secret_key'),
    'client_id': client_data.get('client_id'),
    'redirect_uri': 'https://trade.fyers.in/api-login/redirect-uri/index.html',
    'FY_ID': client_data.get('FY_ID'),
    'PIN': client_data.get('PIN'),
    'TOTP': client_data.get('TOTP')
}
access_token, fyers = login(
    credential.get("secret_key"), credential.get("client_id"),
    credential.get("redirect_uri"), credential.get("FY_ID"),
    credential.get("PIN"), credential.get("TOTP")
)


from fyers_history import HistoricalDataManager
init_hist = HistoricalDataManager(fyers=fyers,symbol="NSE:NIFTY50-INDEX",start_date=dt.date(2018,1,1),end_date=dt.date(2023,12,31),timeframe="1M",save_path=".")
a= dt.datetime.now()
print(init_hist.Long_duration())

print(dt.datetime.now()-a)